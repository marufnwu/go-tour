@extends('admin.layouts.master')

@section('title','Day Itinerary | Edit')

@section('styles')
    <link href="{{ asset('/')}}admin/css/croppie.css" rel="stylesheet"/>
@endsection

@section('content')

    <div class="container-fluid">
        <!-- Page Heading -->
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="{{ route('dashboard') }}">Dashboard</a></li>
                <li class="breadcrumb-item"><a href="{{ route('itinerary.index') }}">Day Itinerary</a></li>
                <li class="breadcrumb-item active" aria-current="page">Edit Day Itinerary</li>
            </ol>
        </nav>

        <!-- DataTales Example -->
        <div class="card shadow mb-4">
            <div class="card-header bg-primary py-3 d-flex justify-content-between align-items-center">
                <h6 class="m-0 font-weight-bold text-white">
                    <i class="fas fa fa-desktop"></i> Edit Day Itinerary
                </h6>

            </div>
            <form id="ajaxForm" class="" action="{{route('itinerary.update',$itineraries->id)}}" method="POST">
                @csrf
                @method('put')
                <div class="card-body">
                    <div class="row">
                        <div class="col-lg-4">
                            <div class="form-group">
                                <label for="" class="font-weight-bold">Day Itinerary<span class="text-danger">*</span></label>
                                <input id="from" type="text" class="form-control" name="day_itinerary" value="{{ $itineraries->day_itinerary }}"  placeholder="">
                                <p id="err-from" class="mb-0 text-danger small em"></p>
                            </div>
                        </div>
                        <div class="col-lg-4">
                            <div class="form-group">
                                <label for="" class="font-weight-bold">General Tour Itinerary<span class="text-danger">*</span></label>
                                <select class="form-control" name="gti_id">
                                  <option value="">Select General Tour Itinerary</option>
                                  @foreach ($gtis as $gti)
                                    <option value="{{ $gti->id }}" {{ $itineraries->gti_id  == $gti->id ? 'selected' : '' }}>{{ $gti->gti_name }}</option>
                                  @endforeach
                                </select>
                            </div>
                        </div>
                        <div class="col-lg-4">
                            <div class="form-group">
                                <label for="" class="font-weight-bold">City<span class="text-danger">*</span></label>
                                <select class="form-control" name="city_id">
                                    <option value="">Select City</option>
                                    @foreach ($cities as $city)
                                    <option value="{{ $city->id }}" {{ $itineraries->city_id  == $city->id ? 'selected' : '' }}>{{ $city->city_name }}</option>
                                    @endforeach
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-4">
                            <div class="form-group">
                                <label for="" class="font-weight-bold">Country<span class="text-danger">*</span></label>
                                <select class="form-control" name="country_id">
                                  <option value="">Select Country</option>
                                  @foreach ($countries as $country)
                                    <option value="{{ $country->id }}" {{ $itineraries->country_id  == $country->id ? 'selected' : '' }}>{{ $country->country_name }}</option>
                                  @endforeach
                                </select>
                            </div>
                        </div>
                        <div class="col-lg-4">
                            <div class="form-group">
                                <label for="" class="font-weight-bold">Activity<span class="text-danger">*</span></label>
                                <select class="form-control" name="activity_id">
                                  <option value="">Select One</option>
                                  @foreach ($activities as $city)
                                    <option value="{{ @$city->id }}" {{ $itineraries->activity_id  == $city->id ? 'selected' : '' }}>{{ @$city->activity_name }}</option>
                                  @endforeach
                                </select>
                            </div>
                        </div>
                        <div class="col-lg-4">
                            <div class="form-group">
                                <label for="" class="font-weight-bold">Sight<span class="text-danger">*</span></label>
                                <select class="form-control" name="sight_id">
                                  <option value="">Select One</option>
                                  @foreach ($sights as $country)
                                    <option value="{{ @$country->id }}" {{ $itineraries->sight_id  == $country->id ? 'selected' : '' }}>{{ @$country->sight_name }}</option>
                                  @endforeach
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-4">
                            <div class="form-group">
                                <label for="" class="font-weight-bold">Sight Distance<span class="text-danger">*</span></label>
                                <select class="form-control" name="sight_distant_id">
                                  <option value="">Select One</option>
                                  @foreach ($distance as $distant)
                                    <option value="{{ @$distant->id }}" {{ $itineraries->sight_distant_id  == $distant->id ? 'selected' : '' }}>{{ @$distant->distant_sight_name }}</option>
                                  @endforeach
                                </select>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="form-group">
                                <label for="" class="font-weight-bold">Airport<span class="text-danger">*</span></label>
                                <select class="form-control" name="airport_id">
                                  <option value="">Select One</option>
                                  @foreach ($airports as $country)
                                    <option value="{{ @$country->id }}" {{ $itineraries->airport_id  == $country->id ? 'selected' : '' }}>{{ @$country->airport_name }}</option>
                                  @endforeach
                                </select>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="card-footer">
                    <div class="row">
                        <div class="col-xl-4 col-lg-4 col-md-4 col-12"></div>
                        <div class="col-xl-4 col-lg-4 col-md-4 col-12">
                            <button type="submit" id="submitBtn" class="btn btn-primary btn-lg btn-block"><i class="fa fa-check-circle" aria-hidden="true"></i> Update</button>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
    <!-- /.container-fluid -->

@endsection


@section('scripts')
    <script src="{{ asset('/')}}admin/js/croppie.js"></script>

    <script>

        /* show file value after file select */
        /*   document.querySelector('.custom-file-input').addEventListener('change',function(e){
               var fileName = document.getElementById("upload_image").files[0].name;
               var nextSibling = e.target.nextElementSibling;
               nextSibling.innerText = fileName;
           });*/

        //================= Image Upload and resize ===================
        $image_crop = $('#image_demo').croppie({
            enableExif: true,
            viewport: {
                width: 200,
                height: 200,
                type: 'square' //circle
            },
            boundary: {
                width: 300,
                height: 300
            }
        });

        $('#upload_image').on('change', function (e) {
            var reader = new FileReader();
            reader.onload = (e) => {
                $('#uploaded_image').html('<img src="'+e.target.result+'" class="img-thumbnail mb-3" style="width:200px; height:220px" />');
                $('.js-avatar').val(this.files[0]);
            }
            reader.readAsDataURL(this.files[0]);

            $('.custom-file-label').text(this.files[0].name);
        });


        $('.crop_image').click(function (event) {
            $image_crop
                .croppie('result', {
                    type: 'canvas',
                    size: 'viewport'
                })
                .then(function (response) {
                    $('.js-avatar').val(response);
                    //console.log(response)
                    $('#uploadimageModal').modal('hide');
                    $('#uploaded_image').html('<img src="'+response+'" class="img-thumbnail mb-3" style="width:200px; height:220px"/>');
                })
        });

        // Image Upload

    </script>
@endsection