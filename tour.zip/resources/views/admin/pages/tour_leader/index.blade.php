@extends('admin.layouts.master')

@section('title','Admin | Manage Tour Leader')

@section('content')

    <div class="container-fluid">
        <!-- Page Heading -->
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="{{ route('dashboard') }}">Dashboard</a></li>
                <li class="breadcrumb-item active" aria-current="page">Manage Tour Leader</li>
            </ol>
        </nav>

        <!-- DataTales Example -->
        <div class="card shadow mb-4">
            <div class="card-header bg-default py-2 d-flex justify-content-between align-items-center">
                <h4 class="m-0 font-weight-bold text-primary">
                    <i class="fas fa-user-circle"></i> Tour Leader Information
                </h4>
                <a href="{{ route('tourleaders.create') }}" class="d-none d-sm-inline-block btn btn-primary shadow-sm btn-rounded" >
                    <i class="fa fa-plus"></i>&nbsp; Add Tour Leader </a>
            </div>
            <div class="card-body">
                <div class="row">

                </div>
                <div class="table-responsive">
                    <table class="table table-bordered" id="dataTable">
                        <thead>
                        <tr>
                            {{-- <th class="text-center">#</th> --}}
                            <th class="align-text-top">First Name</th>
                            <th class="align-text-top">Middle Name</th>
                            <th class="align-text-top">Last Name</th>
                            <th class="align-text-top">Addreass</th>
                            <th class="align-text-top">City</th>
                            <th class="align-text-top">State</th>
                            <th class="align-text-top">Zip</th>
                            <th class="align-text-top">Phone</th>
                            <th class="align-text-top">Email</th>
                            <th class="align-text-top">Denomination</th>
                            <th class="align-text-top">Church Name</th>
                            <th class="align-text-top">Church Denomination</th>
                            <th class="align-text-top">Church Members</th>
                            <th class="align-text-top">Church Phone</th>
                            <th class="align-text-top">Church Email</th>
                            <th class="align-text-top">Church Size</th>
                            <th class="align-text-top">Action</th>
                        </tr>
                        </thead>
                        <tbody>

                        @foreach($tourleaders as $tourleader)
                            <tr>
                                {{-- <td class="text-center">{{ $loop->index+1 }}</td> --}}
                                <td>{{ $tourleader->tlfirst_n }}</td>
                                <td>{{ $tourleader->tl_m_name }}</td>
                                <td>{{ $tourleader->ti_l_name }}</td>
                                <td>{{ $tourleader->address }}</td>
                                <td>{{ $tourleader->city }}</td>
                                <td>{{ $tourleader->state }}</td>
                                <td>{{ $tourleader->zip }}</td>
                                <td>{{ $tourleader->th_phone }}</td>
                                <td>{{ $tourleader->th_email }}</td>
                                <td>{{ $tourleader->denomination }}</td>
                                <td>{{ $tourleader->church_name }}</td>
                                <td>{{ $tourleader->church_denomination }}</td>
                                <td>{{ $tourleader->church_members }}</td>
                                <td>{{ $tourleader->church_phone }}</td>
                                <td>{{ $tourleader->church_email }}</td>
                                <td>{{ $tourleader->church_size }}</td>

                                <td class="text-center">

                                    <a class="btn btn-success btn-sm mb-1" href="{{ route('tourleaders.edit',$tourleader->id) }}">
                                        <i class="fas fa-edit"></i>
                                    </a>

                                    <form class="deleteform d-inline-block" action="{{route('tourleaders.destroy',$tourleader->id)}}" method="post">
                                        @csrf
                                        @method('delete')
                                        <button type="submit" class="btn btn-sm btn-danger deletebtn mb-1">
                                            <span class="btn-label">
                                              <i class="fas fa-trash"></i>
                                            </span>
                                        </button>
                                    </form>

                                </td>
                            </tr>
                        @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <!-- /.container-fluid -->

@endsection


@section('scripts')

@endsection
