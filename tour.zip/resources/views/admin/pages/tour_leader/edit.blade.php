@extends('admin.layouts.master')

@section('title','Admin | Edit Tour Leader')

@section('styles')
    <link href="{{ asset('/')}}admin/css/croppie.css" rel="stylesheet"/>
@endsection

@section('content')

    <div class="container-fluid">
        <!-- Page Heading -->
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="{{ route('dashboard') }}">Dashboard</a></li>
                <li class="breadcrumb-item"><a href="{{ route('tourleaders.index') }}">Manage Tour Leader</a></li>
                <li class="breadcrumb-item active" aria-current="page"> Edit Tour Leader Information</li>
            </ol>
        </nav>

        <!-- DataTales Example -->
        <div class="card shadow mb-4">
            <div class="card-header bg-primary py-3 d-flex justify-content-between align-items-center">
                <h6 class="m-0 font-weight-bold text-white">
                    <i class="fas fa fa-desktop"></i> Edit Tour Leader Information
                </h6>

            </div>
            <form id="ajaxForm" class="" action="{{route('tourleaders.update',$tourleaders->id)}}" method="POST">
                @csrf
                @method('put')
                <div class="card-body">
                    <div class="row">
                        <div class="col-lg-4">
                            <div class="form-group">
                                <label for="" class="font-weight-bold">First Name <span class="text-danger">*</span></label>
                                <input id="from" type="text" class="form-control" name="fname" value="{{ $tourleaders->tlfirst_n }}"  placeholder="">
                                <p id="err-from" class="mb-0 text-danger small em"></p>
                            </div>
                        </div>
                        <div class="col-lg-4">
                            <div class="form-group">
                                <label for="" class="font-weight-bold">Middle Name<span class="text-danger">*</span></label>
                                <input id="to" type="text" class="form-control" name="mname" value="{{ $tourleaders->tl_m_name }}"  placeholder="">
                                <p id="err-to" class="mb-0 text-danger small em"></p>
                            </div>
                        </div>
                        <div class="col-lg-4">
                          <div class="form-group">
                              <label for="" class="font-weight-bold">Last Name<span class="text-danger">*</span></label>
                              <input id="to" type="text" class="form-control" name="lname" value="{{ $tourleaders->ti_l_name }}"  placeholder="">
                              <p id="err-to" class="mb-0 text-danger small em"></p>
                          </div>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-lg-4">
                        <div class="form-group">
                            <label for="" class="font-weight-bold">Address<span class="text-danger">*</span></label>
                            <input id="to" type="text" class="form-control" name="address" value="{{ $tourleaders->address }}"  placeholder="">
                            <p id="err-to" class="mb-0 text-danger small em"></p>
                        </div>
                      </div>
                      <div class="col-lg-4">
                        <div class="form-group">
                            <label for="" class="font-weight-bold">City<span class="text-danger">*</span></label>
                            <input id="to" type="text" class="form-control" name="city" value="{{ $tourleaders->city }}"  placeholder="">
                            <p id="err-to" class="mb-0 text-danger small em"></p>
                        </div>
                      </div>
                      <div class="col-lg-4">
                        <div class="form-group">
                            <label for="" class="font-weight-bold">State<span class="text-danger">*</span></label>
                            <input id="to" type="text" class="form-control" name="state" value="{{ $tourleaders->state }}"  placeholder="">
                            <p id="err-to" class="mb-0 text-danger small em"></p>
                        </div>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-lg-4">
                        <div class="form-group">
                            <label for="" class="font-weight-bold">Zip<span class="text-danger">*</span></label>
                            <input id="to" type="number" class="form-control" name="zip" value="{{ $tourleaders->zip }}"  placeholder="">
                            <p id="err-to" class="mb-0 text-danger small em"></p>
                        </div>
                      </div>
                      <div class="col-lg-4">
                        <div class="form-group">
                            <label for="" class="font-weight-bold">Church Name<span class="text-danger">*</span></label>
                            <input id="to" type="text" class="form-control" name="chname" value="{{ $tourleaders->church_name }}"  placeholder="">
                            <p id="err-to" class="mb-0 text-danger small em"></p>
                        </div>
                      </div>
                      <div class="col-lg-4">
                        <div class="form-group">
                            <label for="" class="font-weight-bold">Church Denomination<span class="text-danger">*</span></label>
                            <input id="to" type="text" class="form-control" name="chdenomination" value="{{ $tourleaders->church_denomination }}"  placeholder="">
                            <p id="err-to" class="mb-0 text-danger small em"></p>
                        </div>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-lg-4">
                        <div class="form-group">
                            <label for="" class="font-weight-bold">Church Members<span class="text-danger">*</span></label>
                            <input id="to" type="text" class="form-control" name="chmember" value="{{ $tourleaders->church_members }}"  placeholder="">
                            <p id="err-to" class="mb-0 text-danger small em"></p>
                        </div>
                      </div>
                      <div class="col-lg-4">
                        <div class="form-group">
                            <label for="" class="font-weight-bold">Church Phone<span class="text-danger">*</span></label>
                            <input id="to" type="text" class="form-control" name="chphone" value="{{ $tourleaders->church_phone }}"  placeholder="">
                            <p id="err-to" class="mb-0 text-danger small em"></p>
                        </div>
                      </div>
                      <div class="col-lg-4">
                        <div class="form-group">
                            <label for="" class="font-weight-bold">Church Email<span class="text-danger">*</span></label>
                            <input id="to" type="email" class="form-control" name="chemail" value="{{ $tourleaders->church_email }}"  placeholder="">
                            <p id="err-to" class="mb-0 text-danger small em"></p>
                        </div>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-lg-4">
                        <div class="form-group">
                            <label for="" class="font-weight-bold">Email<span class="text-danger">*</span></label>
                            <input id="to" type="email" class="form-control" name="email" value="{{ $tourleaders->th_email }}" placeholder="">
                            <p id="err-to" class="mb-0 text-danger small em"></p>
                        </div>
                      </div>
                      <div class="col-lg-4">
                        <div class="form-group">
                            <label for="" class="font-weight-bold">Phone<span class="text-danger">*</span></label>
                            <input id="to" type="text" class="form-control" name="phone" value="{{ $tourleaders->th_phone }}"  placeholder="">
                            <p id="err-to" class="mb-0 text-danger small em"></p>
                        </div>
                      </div>
                      <div class="col-lg-4">
                        <div class="form-group">
                            <label for="" class="font-weight-bold">Church Size<span class="text-danger">*</span></label>
                            <input id="to" type="text" class="form-control" name="chsize" value="{{ $tourleaders->church_size }}"  placeholder="">
                            <p id="err-to" class="mb-0 text-danger small em"></p>
                        </div>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-lg-6">
                        <div class="form-group">
                            <label for="" class="font-weight-bold">Denomination	<span class="text-danger">*</span></label>
                            <input id="to" type="text" class="form-control" name="denomination" value="{{ $tourleaders->denomination }}"  placeholder="">
                            <p id="err-to" class="mb-0 text-danger small em"></p>
                        </div>
                      </div>
                      <div class="col-lg-6">
                        <div class="form-group">
                            <label for="" class="font-weight-bold">User	<span class="text-danger">*</span></label>
                            <input id="to" type="text" class="form-control" name="user" value="{{ $tourleaders->user }}" placeholder="">
                            <p id="err-to" class="mb-0 text-danger small em"></p>
                        </div>
                      </div>
                    </div>
                </div>
                <div class="card-footer">
                    <div class="row">
                        <div class="col-xl-4 col-lg-4 col-md-4 col-12"></div>
                        <div class="col-xl-4 col-lg-4 col-md-4 col-12">
                            <button type="submit" id="submitBtn" class="btn btn-primary btn-lg btn-block"><i class="fa fa-check-circle" aria-hidden="true"></i> Update</button>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
    <!-- /.container-fluid -->

    <div id="uploadimageModal" class="modal" role="dialog">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header blue-gradient-rgba">
                    {{-- <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title">Upload & Crop Image</h4> --}}

                    <h5 class="modal-title my-0 py-0 text-white" id=""><i class="far fa-image"></i> Crop Image </h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>


                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-8 col-lg-8 col-xl-8 col-12 text-center mx-auto">
                            <div id="image_demo" style="width:350px; margin:auto"></div>
                        </div>
                        <div class="col-md-4 col-lg-4 col-xl-4 col-12 text-center mx-auto my-auto">
                            <button type="button" class="btn btn-outline-success crop_image"><i class="far fa-image"></i> Crop & Upload Image</button>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-outline-danger" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>

@endsection


@section('scripts')
    <script src="{{ asset('/')}}admin/js/croppie.js"></script>

    <script>

        /* show file value after file select */
        /*   document.querySelector('.custom-file-input').addEventListener('change',function(e){
               var fileName = document.getElementById("upload_image").files[0].name;
               var nextSibling = e.target.nextElementSibling;
               nextSibling.innerText = fileName;
           });*/

        //================= Image Upload and resize ===================
        $image_crop = $('#image_demo').croppie({
            enableExif: true,
            viewport: {
                width: 200,
                height: 200,
                type: 'square' //circle
            },
            boundary: {
                width: 300,
                height: 300
            }
        });

        $('#upload_image').on('change', function (e) {
            var reader = new FileReader();
            reader.onload = (e) => {
                $('#uploaded_image').html('<img src="'+e.target.result+'" class="img-thumbnail mb-3" style="width:200px; height:220px" />');
                $('.js-avatar').val(this.files[0]);
            }
            reader.readAsDataURL(this.files[0]);

            $('.custom-file-label').text(this.files[0].name);
        });


        $('.crop_image').click(function (event) {
            $image_crop
                .croppie('result', {
                    type: 'canvas',
                    size: 'viewport'
                })
                .then(function (response) {
                    $('.js-avatar').val(response);
                    //console.log(response)
                    $('#uploadimageModal').modal('hide');
                    $('#uploaded_image').html('<img src="'+response+'" class="img-thumbnail mb-3" style="width:200px; height:220px"/>');
                })
        });

        // Image Upload

    </script>
@endsection
