<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Activity;
use App\Models\Hotel;
use App\Models\Reservation;
use App\Models\Tourleadertour;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Redirect;

class ReservationController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $reservations = Reservation::all();
        return view('admin.pages.reservation.index', compact('reservations'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $hotels = Hotel::all();
        $tours = Tourleadertour::all();
        return view('admin.pages.reservation.add',compact('hotels','tours'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $reservations = new Reservation();
        $reservations->hotel_id= $request ->input('hotel_id');
        $reservations->tourleader_tour_id= $request ->input('tourleader_tour_id');
        $reservations->from_date= $request ->input('from_date');
        $reservations->to_date= $request ->input('to_date');
        $reservations->single_room= $request ->input('single_room');
        $reservations->double_room= $request ->input('double_room');
        $reservations->triple_room= $request ->input('triple_room');
        
        $reservations->single_room_price = $request ->input('single_room_price');
        $reservations->double_room_price = $request ->input('double_room_price');
        $reservations->triple_room_price = $request ->input('triple_room_price');

        $reservations->total_passenger= $request ->input('total_passenger');
        $reservations->reservation_date= $request ->input('reservation_date');
        $reservations->confirmation_date= $request ->input('confirmation_date');

        $reservations->save();

        Session::flash('success', 'Reservation has been Added Successfully');
        return 'success';
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $hotels = Hotel::all();
        $tours = Tourleadertour::all();
        $reservations = Reservation::find($id);
        return view('admin.pages.reservation.edit', compact('hotels','reservations', 'tours'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $reservations = Reservation::find($id);
        if($request ->input('hotel_id')){
            $reservations->hotel_id= $request ->input('hotel_id');
        }
        $reservations->tourleader_tour_id= $request ->input('tourleader_tour_id');
        $reservations->from_date= $request ->input('from_date');
        $reservations->to_date= $request ->input('to_date');
        $reservations->single_room= $request ->input('single_room');
        $reservations->double_room= $request ->input('double_room');
        $reservations->triple_room= $request ->input('triple_room');

        $reservations->single_room_price = $request ->input('single_room_price');
        $reservations->double_room_price = $request ->input('double_room_price');
        $reservations->triple_room_price = $request ->input('triple_room_price');

        $reservations->total_passenger= $request ->input('total_passenger');
        $reservations->reservation_date= $request ->input('reservation_date');
        $reservations->confirmation_date= $request ->input('confirmation_date');

        $reservations->update();
        Session::flash('success', 'Reservation has been Updated Successfully');
        return 'success';
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $reservations= Reservation::find($id);
        $reservations-> delete();
        
        Session::flash('success', 'Reservations has been Deleted Successfully');
        return Redirect::route('reservation.index');
    }
}
