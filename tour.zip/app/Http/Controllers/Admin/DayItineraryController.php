<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Dayitinerary;
use App\Models\City;
use App\Models\Country;
use App\Models\Gti;

use App\Models\Activity;
use App\Models\Airport;
use App\Models\Sight;
use App\Models\Sightdistant;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Session;

class DayItineraryController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $itineraries = Dayitinerary::all();
        return view('admin.pages.day_itinerary.index', compact('itineraries'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $cities = City::all();
        $countries = Country::all();
        $gtis = Gti::all();

        $activities = Activity::all();
        $sights = Sight::all();
        $airports = Airport::all();
        $distance = Sightdistant::all();
        return view('admin.pages.day_itinerary.add', compact(
            'cities', 'countries', 'gtis',
            'airports', 'sights', 'activities',
            'distance'
        ));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $itineraries = new Dayitinerary();
        
        $itineraries->day_itinerary= $request ->input('day_itinerary');
        $itineraries->gti_id= $request->input('gti_id');
        $itineraries->country_id= $request->input('country_id');
        $itineraries->city_id= $request->input('city_id');
        $itineraries->sight_id= $request->input('sight_id');
        $itineraries->sight_distant_id= $request->input('sight_distant_id');
        $itineraries->airport_id= $request->input('airport_id');
        $itineraries->activity_id= $request->input('activity_id');


        $itineraries-> save();

        Session::flash('success', 'Day Itinerary has been Added Successfully');
        return 'success';
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $itineraries = Dayitinerary::find($id);
        $gtis = Gti::all();
        $cities = City::all();
        $countries = Country::all();
        $activities = Activity::all();
        $sights = Sight::all();
        $airports = Airport::all();
        $distance = Sightdistant::all();
        return view('admin.pages.day_itinerary.edit', compact(
            'cities', 'countries', 'gtis',
            'airports', 'sights', 'activities',
            'distance', 'itineraries'
        ));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $itineraries = Dayitinerary::find($id);

        $itineraries->day_itinerary= $request ->input('day_itinerary');
        $itineraries->gti_id= $request->input('gti_id');
        $itineraries->country_id= $request->input('country_id');
        $itineraries->city_id= $request->input('city_id');
        $itineraries->sight_id= $request->input('sight_id');
        $itineraries->sight_distant_id= $request->input('sight_distant_id');
        $itineraries->airport_id= $request->input('airport_id');
        $itineraries->activity_id= $request->input('activity_id');

        $itineraries->update();

        Session::flash('success', 'Day Itinerary has been Updated Successfully');
        return 'success';
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $itineraries = Dayitinerary::find($id);
        $itineraries ->delete();
        
        Session::flash('success', 'Day Itinerary has been Deleted Successfully');
        return Redirect::route('itinerary.index');
    }
}
