<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Tourleader;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Redirect;

class TourLeaderController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $tourleaders = Tourleader::all();
        return view('admin.pages.tour_leader.index', compact('tourleaders'));

    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('admin.pages.tour_leader.add');
    }

    public function signup()
    {
        return view('admin.pages.tour_leader.signup');
    }

    public function postSignup(Request $request)
    {
        $is_exist = User::where('email', $request->email)->first();
        if(!$is_exist) {
            $users = new User();
            $users = [
                'name'=> $request->fname,
                'email'=> $request->email,
                'phone'=> $request->phone,
                'password'=> Hash::make($request-> password),
                'type' => 'Leader',
                'created_at' => now(),
                'updated_at' => now(),
            ];
            User::insert($users);
            $tourleaders = new Tourleader();
            $tourleaders->tlfirst_n= $request ->input('fname');
            $tourleaders->tl_m_name= $request->input('mname');
            $tourleaders->ti_l_name= $request ->input('lname');
            $tourleaders->address= $request->input('address');
            $tourleaders->city= $request ->input('city');
            $tourleaders->state= $request->input('state');
            $tourleaders->zip= $request ->input('zip');
            $tourleaders->church_name= $request->input('chname');
            $tourleaders->church_denomination= $request ->input('chdenomination');
            $tourleaders->church_members= $request->input('chmember');
            $tourleaders->church_phone= $request ->input('chphone');
            $tourleaders->church_email= $request->input('chemail');
            $tourleaders->th_email= $request ->input('email');
            $tourleaders->th_phone= $request->input('phone');
            $tourleaders->church_size= $request ->input('chsize');
            $tourleaders->denomination= $request->input('denomination');
            $tourleaders->user= $request->input('user');
            $tourleaders->password= Hash::make($request->input('password'));
            $tourleaders->save();
            
            Session::flash('success', 'You Have Registered Successfully');
            return 'success';
        } else {
            Session::flash('warning', 'This email already exist.');
            return 'success';
        }
    
    }
    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $is_exist = User::where('email', $request->email)->first();
        if(!$is_exist) {
            

            $tourleaders = new Tourleader();
            $tourleaders->tlfirst_n= $request ->input('fname');
            $tourleaders->tl_m_name= $request->input('mname');
            $tourleaders->ti_l_name= $request ->input('lname');
            $tourleaders->address= $request->input('address');
            $tourleaders->city= $request ->input('city');
            $tourleaders->state= $request->input('state');
            $tourleaders->zip= $request ->input('zip');
            $tourleaders->church_name= $request->input('chname');
            $tourleaders->church_denomination= $request ->input('chdenomination');
            $tourleaders->church_members= $request->input('chmember');
            $tourleaders->church_phone= $request ->input('chphone');
            $tourleaders->church_email= $request->input('chemail');
            $tourleaders->th_email= $request ->input('email');
            $tourleaders->th_phone= $request->input('phone');
            $tourleaders->church_size= $request ->input('chsize');
            $tourleaders->denomination= $request->input('denomination');
            $tourleaders->user= $request->input('user');
            $tourleaders->password= Hash::make($request->input('password'));
            $tourleaders->save();

            $users = new User();
            $users = [
                'name'=> $request->fname,
                'email'=> $request->email,
                'phone'=> $request->phone,
                'password'=> Hash::make($request-> password),
                'type' => 'Leader',
                'created_at' => now(),
                'updated_at' => now(),
            ];
            User::insert($users);
        
            Session::flash('success', 'Leader Information has been Added Successfully');
            return 'success';
        } else {
            Session::flash('warning', 'This email already exist.');
            return 'success';
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $tourleaders = Tourleader::find($id);
        return view('admin.pages.tour_leader.edit', compact('tourleaders'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $tourleaders = Tourleader::find($id);
        $tourleaders->tlfirst_n= $request ->input('fname');
        $tourleaders->tl_m_name= $request->input('mname');
        $tourleaders->ti_l_name= $request ->input('lname');
        $tourleaders->address= $request->input('address');
        $tourleaders->city= $request ->input('city');
        $tourleaders->state= $request->input('state');
        $tourleaders->zip= $request ->input('zip');
        $tourleaders->church_name= $request->input('chname');
        $tourleaders->church_denomination= $request ->input('chdenomination');
        $tourleaders->church_members= $request->input('chmember');
        $tourleaders->church_phone= $request ->input('chphone');
        $tourleaders->church_email= $request->input('chemail');
        $tourleaders->th_email= $request ->input('email');
        $tourleaders->th_phone= $request->input('phone');
        $tourleaders->church_size= $request ->input('chsize');
        $tourleaders->denomination= $request->input('denomination');
        $tourleaders->user= $request->input('user');
        $tourleaders->update();

        Session::flash('success', 'Leader Information has been Updated Successfully');
        return 'success';
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $tourleaders = Tourleader::find($id);
        $tourleaders->delete();
        Session::flash('success', 'Leader Information has been Deleted Successfully');
        return Redirect::route('tourleaders.index');
    
    }
}
