<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Airport;
use App\Models\Airticket;
use App\Models\Passengerinfo;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Redirect;


class AirlineTicketController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $tickets= Airticket::all();
        return view('admin.pages.airline_ticket.index',compact('tickets'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $passengers = Passengerinfo::all();

        $airports = Airport::all();
        return view('admin.pages.airline_ticket.add', compact('passengers', 'airports'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $tickets = new Airticket();
        $tickets->passenger_id= $request ->input('passenger_id');
        $tickets->city_of_depart= $request ->input('city_of_depart');
        $tickets->city_of_arrival= $request ->input('city_of_arrival');
        $tickets->departure_date_time= $request ->input('departure_date_time');
        $tickets->arrival_date_time= $request ->input('arrival_date_time');
        $tickets->ticket_pnr= $request ->input('ticket_pnr');
        $tickets->airline= $request ->input('airline');
        $tickets->ticket_price= $request ->input('ticket_price');

        $tickets->save();
        Session::flash('success', 'Airline Ticket has been Added Successfully');
        return 'success';
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $tickets = Airticket::find($id);
        $passengers = Passengerinfo::all();
        return view('admin.pages.airline_ticket.edit', compact('tickets', 'passengers'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $tickets = Airticket::find($id);
        $tickets->passenger_id= $request ->input('passenger_id');
        $tickets->city_of_depart= $request ->input('city_of_depart');
        $tickets->city_of_arrival= $request ->input('city_of_arrival');
        $tickets->departure_date_time= $request ->input('departure_date_time');
        $tickets->arrival_date_time= $request ->input('arrival_date_time');
        $tickets->ticket_pnr= $request ->input('ticket_pnr');
        $tickets->airline= $request ->input('airline');
        $tickets->ticket_price= $request ->input('ticket_price');

        $tickets->update();
        Session::flash('success', 'Airline Ticket has been Updated Successfully');
        return 'success';
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $tickets= Airticket::find($id);
        $tickets-> delete();
        
        Session::flash('success', 'Airline Ticket has been Deleted Successfully');
        return Redirect::route('ticket_list.index');
    }
}
