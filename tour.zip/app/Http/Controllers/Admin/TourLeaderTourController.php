<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Gti;
use App\Models\City;
use App\Models\Tourleader;
use App\Models\Tourleadertour;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Session;

class TourLeaderTourController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $tours = Tourleadertour::all();
        return view('admin.pages.tourleader_tour.index', compact('tours'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $tourleaders = Tourleader::all();
        $gtis = Gti::all();
        $cities = City::all();
        return view('admin.pages.tourleader_tour.add', compact('tourleaders', 'gtis', 'cities'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $tours = new Tourleadertour();
        $tours->tourleader_id= $request ->input('tourleader_id');
        $tours->gti_id= $request ->input('gti_id');
        $tours->tour_name= $request->input('tour_name');
        $tours->athens_departure_date= $request->input('athens_departure_date');
        $tours->tour_cost= $request->input('tour_cost');
        $tours->language= $request->input('language');
        $tours->tour_code= $request->input('tour_code');

        $tours->save();


        Session::flash('success', 'Tour Leader Tour has been Added Successfully');
        return 'success';

    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $tours = Tourleadertour::find($id);
        $gtis = Gti::all();
        $tourleaders = Tourleader::all();
        return view('admin.pages.tourleader_tour.edit', compact('tours', 'gtis', 'tourleaders'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $tours = Tourleadertour::find($id);
        $tours->tourleader_id= $request ->input('tourleader_id');
        $tours->gti_id= $request ->input('gti_id');
        $tours->tour_name= $request->input('tour_name');
        $tours->athens_departure_date= $request->input('athens_departure_date');
        $tours->tour_cost= $request->input('tour_cost');
        $tours->language= $request->input('language');
        $tours->tour_code= $request->input('tour_code');

        $tours->update();

        Session::flash('success', 'Tour Leader Tour has been Updated Successfully');
        return 'success';
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $tours = Tourleadertour::find($id);
        $tours -> delete();

        Session::flash('success', 'Tour Leader Tour has been Deleted Successfully');
        return Redirect::route('tourleader_tour.index');
    }
}
