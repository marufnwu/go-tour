<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Hotel;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Hash;

class HotelController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $hotels= Hotel::all();
        return view('admin.pages.hotel.index', compact('hotels'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('admin.pages.hotel.add');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $is_exist = User::where('email', $request->hotel_email)->first();
        if(!$is_exist) {
            $users = new User();
            $users = [
                'name'=> $request->hotel_name,
                'email'=> $request->hotel_email,
                'phone'=> $request->hotel_phone,
                'password'=> Hash::make($request-> password),
                'type' => 'Hotel',
                'created_at' => now(),
                'updated_at' => now(),
            ];
            User::insert($users);
    
            // step 2
            $hotels = new Hotel();
            $hotels->hotel_name= $request ->input('hotel_name');
            $hotels->hotel_address= $request ->input('hotel_address');
            $hotels->hotel_city= $request ->input('hotel_city');
            $hotels->hotel_country= $request ->input('hotel_country');
            $hotels->hotel_phone= $request ->input('hotel_phone');
            $hotels->hotel_email= $request ->input('hotel_email');
            $hotels->password= Hash::make($request ->input('password'));
    
            
    
            $hotels->save();
            Session::flash('success', 'Hotel has been Added Successfully');
            return 'success';
        } else {
            Session::flash('warning', 'This email already exist.');
            return 'success';
        }        
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $hotels = Hotel::find($id);
        return view('admin.pages.hotel.edit', compact('hotels'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $hotels = Hotel::find($id);

        $hotels->hotel_name= $request ->input('hotel_name');
        $hotels->hotel_address= $request ->input('hotel_address');
        $hotels->hotel_city= $request ->input('hotel_city');
        $hotels->hotel_country= $request ->input('hotel_country');
        $hotels->hotel_phone= $request ->input('hotel_phone');
        $hotels->hotel_email= $request ->input('hotel_email');
        if($request ->input('password')){
            $hotels->password= Hash::make($request ->input('password'));
        }

        $hotels->update();
        Session::flash('success', 'Hotel has been Updated Successfully');
        return 'success';
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $hotels= Hotel::find($id);
        $hotels-> delete();
        
        Session::flash('success', 'Hotel has been Deleted Successfully');
        return Redirect::route('hotel.index');
    }
}
