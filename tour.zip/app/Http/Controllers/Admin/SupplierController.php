<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Supplier;
use App\Models\Suppliertype;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Redirect;

class SupplierController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $suppliers = Supplier::all();
        return view('admin.pages.supplier.index', compact('suppliers'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $types = Suppliertype::all();
        return view('admin.pages.supplier.add', compact('types'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $is_exist = User::where('email', $request->s_email)->first();
        if(!$is_exist) {
            $users = new User();
            $users = [
                'name'=> $request->s_first_name,
                'email'=> $request->s_email,
                'phone'=> $request->s_phone,
                'password'=> Hash::make($request-> s_password),
                'type' => $request->type,
                'created_at' => now(),
                'updated_at' => now(),
            ];
            User::insert($users);

        $suppliers = new Supplier();
        $suppliers->s_first_name= $request ->input('s_first_name');
        $suppliers->s_last_name= $request ->input('s_last_name');
        $suppliers->s_city= $request ->input('s_city');
        $suppliers->s_country= $request ->input('s_country');
        $suppliers->s_phone= $request ->input('s_phone');
        $suppliers->s_email= $request ->input('s_email');
        $suppliers->type= $request ->input('type');
        $suppliers->s_password= Hash::make($request ->input('s_password'));
        $suppliers->save();

            Session::flash('success', 'Supplier has been Added Successfully');
            return 'success';
        } else {
            Session::flash('warning', 'This email already exist.');
            return 'success';
        }
        
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $suppliers = Supplier::find($id);
        $types = Suppliertype::all();
        return view('admin.pages.supplier.edit', compact('suppliers', 'types'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $suppliers = Supplier::find($id);
        $suppliers->s_first_name= $request ->input('s_first_name');
        $suppliers->s_last_name= $request ->input('s_last_name');
        $suppliers->s_city= $request ->input('s_city');
        $suppliers->s_country= $request ->input('s_country');
        $suppliers->s_phone= $request ->input('s_phone');
        $suppliers->s_email= $request ->input('s_email');
        $suppliers->type= $request ->input('type');
        if($request ->input('s_password')){
            $suppliers->s_password= Hash::make($request ->input('s_password'));
        }

        $suppliers->update();
        Session::flash('success', 'Supplier has been Updated Successfully');
        return 'success';
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $suppliers = Supplier::find($id);
        $suppliers -> delete();
        
        Session::flash('success', 'Supplier has been Deleted Successfully');
        return Redirect::route('supplier.index');
    }
}
