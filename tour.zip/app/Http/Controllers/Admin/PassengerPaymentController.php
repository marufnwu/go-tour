<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Passengerinfo;
use App\Models\Passengerpayment;
use App\Models\Paymentmethod;
use App\Models\Tourleadertour;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Redirect;


class PassengerPaymentController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $payments = Passengerpayment::all();
        return view('admin.pages.passenger_payment.index',compact('payments'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $tours = Tourleadertour::all();
        $passengers = Passengerinfo::all();
        $types = Paymentmethod::all();
        return view('admin.pages.passenger_payment.add', compact('tours','passengers','types'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $payments = new Passengerpayment();
        
        $payments->date_of_payment= $request ->input('date_of_payment');
        if (auth()->user()->type=='Admin') {
            $payments->passenger_id= $request ->input('passenger_id');
        } else {
            $payments->passenger_id = Auth::user()->id;
        }
        $payments->type_id= $request ->input('type_id');
        $payments->tourleader_tour_id= $request ->input('tourleader_tour_id');
        $payments->amount= $request ->input('amount');
        $payments->payment_references= $request ->input('payment_references');

        $payments->save();
        Session::flash('success', 'Payment has been Added Successfully');
        return 'success';
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $payments = Passengerpayment::find($id);
        $tours = Tourleadertour::all();
        $passengers = Passengerinfo::all();
        $types = Paymentmethod::all();
        return view('admin.pages.passenger_payment.edit', compact('payments','tours','passengers','types'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $payments = Passengerpayment::find($id);
        
        $payments->date_of_payment= $request ->input('date_of_payment');
        if (auth()->user()->type=='Admin') {
            $payments->passenger_id= $request ->input('passenger_id');
        } else {
            $payments->passenger_id = Auth::user()->id;
        }
        $payments->type_id= $request ->input('type_id');
        $payments->tourleader_tour_id= $request ->input('tourleader_tour_id');
        $payments->amount= $request ->input('amount');
        $payments->payment_references= $request ->input('payment_references');
        $payments->update();
        Session::flash('success', 'Payment has been Updated Successfully');
        return 'success';
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $payments= Passengerpayment::find($id);
        $payments-> delete();

        Session::flash('success', 'Payment has been Deleted Successfully');
        return Redirect::route('payment_passenger.index');
    }
}
