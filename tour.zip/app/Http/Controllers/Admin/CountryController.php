<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Country;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Session;


class CountryController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $countries = Country::all();
        return view('admin.pages.country.index', compact('countries'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('admin.pages.country.add');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $is_exist = Country::where('country_name', $request->name)->first();
        if(!$is_exist) {
            $countries = new Country();
        
            $countries->country_name= $request ->input('name');
            $countries->country_time_zone= $request->input('time_zone');
            $countries->country_area_code= $request ->input('code');

            $countries->save();
            Session::flash('success', 'Country has been Added Successfully');
            return 'success';
        }else{
            Session::flash('warning', 'This Country already exist.');
            return 'success';
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $countries = Country::find($id);
        return view('admin.pages.country.edit', compact('countries'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $countries = Country::find($id);
        $countries->country_name= $request ->input('name');
        $countries->country_time_zone= $request->input('time_zone');
        $countries->country_area_code= $request ->input('code');

        $countries->update();
        Session::flash('success', 'Country has been Added Successfully');
        return 'success';
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $countries = Country::find($id);
        $countries->delete();
        Session::flash('success', 'Country has been Deleted Successfully');
        return Redirect::route('country.index');
    }
}
