<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Gti;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Redirect;

class GtiController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $gtis = Gti::all();
        return view('admin.pages.general_tour_itinerary.index', compact('gtis'));
    }

    /**
     * Show the form for creating a new resource. 
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('admin.pages.general_tour_itinerary.add');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $gtis = new Gti();
        $gtis->gti_name= $request ->input('gti_name');
        $gtis->hotel_address= $request->input('hotel_address');
        $gtis->gti_total_days= $request ->input('gti_total_days');

        $gtis->save();

        Session::flash('success', 'GTI has been Added Successfully');
        return 'success';

    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $gtis = Gti::find($id);
        return view('admin.pages.general_tour_itinerary.edit', compact('gtis'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $gtis = Gti::find($id);
        $gtis->gti_name= $request ->input('gti_name');
        $gtis->hotel_address= $request->input('hotel_address');
        $gtis->gti_total_days= $request ->input('gti_total_days');

        $gtis->update();
        
        Session::flash('success', 'Gti has been Updated Successfully');
        return 'success';
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $gtis = Gti::find($id);
        $gtis->delete();
        Session::flash('success', 'Gti has been Deleted Successfully');
        return Redirect::route('gti.index');
    }

    //ajax
    public function get_gti_total_days($id)
    {
        $gti = Gti::find($id);
        return  $gti->gti_total_days ? $gti->gti_total_days : 0;
    }
}
