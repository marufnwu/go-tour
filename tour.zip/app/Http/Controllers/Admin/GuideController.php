<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Guide;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Hash;

class GuideController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $guides = Guide::all();
        return view('admin.pages.guide.index', compact('guides'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('admin.pages.guide.add');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $is_exist = User::where('email', $request->guide_email)->first();
        if(!$is_exist) {
            $users = new User();
            $users = [
                'name'=> $request->guide_first_n,
                'email'=> $request->guide_email,
                'phone'=> $request->guide_phone,
                'password'=> Hash::make($request-> password),
                'type' => 'Guide',
                'created_at' => now(),
                'updated_at' => now(),
            ];
        User::insert($users);


        $guides = new Guide();
        $guides->guide_first_n= $request ->input('guide_first_n');
        $guides->guide_m_name= $request ->input('guide_m_name');
        $guides->guide_l_name= $request ->input('guide_l_name');
        $guides->guide_address= $request ->input('guide_address');
        $guides->guide_city= $request ->input('guide_city');
        $guides->guide_country= $request ->input('guide_country');
        $guides->guide_phone= $request ->input('guide_phone');
        $guides->guide_email= $request ->input('guide_email');
        $guides->password= $request ->input('password');
        $guides->guide_fees_per_day= $request ->input('guide_fees_per_day');

        $guides->save();
        Session::flash('success', 'Guide has been Added Successfully');
        return 'success';
        } else {
            Session::flash('success', 'Guide has been Added Successfully');
            return 'success';
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $guides = Guide::find($id);
        return view('admin.pages.guide.edit', compact('guides'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $guides = Guide::find($id);
        $guides->guide_first_n= $request ->input('guide_first_n');
        $guides->guide_m_name= $request ->input('guide_m_name');
        $guides->guide_l_name= $request ->input('guide_l_name');
        $guides->guide_address= $request ->input('guide_address');
        $guides->guide_city= $request ->input('guide_city');
        $guides->guide_country= $request ->input('guide_country');
        $guides->guide_phone= $request ->input('guide_phone');
        $guides->guide_email= $request ->input('guide_email');
        if($request ->input('password')){
            $guides->password= Hash::make($request ->input('password'));
        }
        $guides->guide_fees_per_day= $request ->input('guide_fees_per_day');

        $guides->update();
        Session::flash('success', 'Guide has been Updated Successfully');
        return 'success';
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $guides= Guide::find($id);
        $guides-> delete();
        
        Session::flash('success', 'Guide has been Deleted Successfully');
        return Redirect::route('guide.index');
    }
}
